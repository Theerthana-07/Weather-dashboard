# Weather Dashboard

Search any city and see its current weather: temperature, feels-like, humidity, wind and conditions.

## Features
- City search using the Open-Meteo geocoding and forecast APIs (free, no API key)
- Current conditions with icon and a background that changes with weather and day/night
- Input validation and error handling: empty input, invalid characters, city not found, network failure, API errors
- Loading indicator, °C/°F toggle, last five searches saved in the browser
- Responsive layout

## Run
Open `index.html` in a browser (internet connection required).

## Tech
HTML5, CSS3, ES6+ JavaScript (async/await, fetch, template literals, destructuring).

## Project structure
- `index.html`: markup
- `style.css`: styles and weather themes
- `script.js`: API calls, validation, rendering

## Suggested Git commits
- `feat: add search form with input validation`
- `feat: fetch city coordinates and current weather from Open-Meteo`
- `feat: render weather card with icons and themed background`
- `feat: add unit toggle and recent searches`
- `fix: show friendly message for network and API errors`
- `docs: add README`
