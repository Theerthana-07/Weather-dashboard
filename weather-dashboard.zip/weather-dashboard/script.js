// Weather Dashboard: Open-Meteo geocoding + forecast APIs (free, no key).
const GEO_URL = "https://geocoding-api.open-meteo.com/v1/search";
const WEATHER_URL = "https://api.open-meteo.com/v1/forecast";

// WMO weather codes -> [description, emoji, theme]
const CODES = {
  0: ["Clear sky", "☀️", "clear"], 1: ["Mainly clear", "🌤️", "clear"], 2: ["Partly cloudy", "⛅", "cloudy"],
  3: ["Overcast", "☁️", "cloudy"], 45: ["Fog", "🌫️", "cloudy"], 48: ["Freezing fog", "🌫️", "cloudy"],
  51: ["Light drizzle", "🌦️", "rain"], 53: ["Drizzle", "🌦️", "rain"], 55: ["Heavy drizzle", "🌧️", "rain"],
  61: ["Light rain", "🌧️", "rain"], 63: ["Rain", "🌧️", "rain"], 65: ["Heavy rain", "🌧️", "rain"],
  71: ["Light snow", "🌨️", "snow"], 73: ["Snow", "🌨️", "snow"], 75: ["Heavy snow", "❄️", "snow"],
  80: ["Rain showers", "🌦️", "rain"], 81: ["Heavy showers", "🌧️", "rain"], 82: ["Violent showers", "🌧️", "rain"],
  95: ["Thunderstorm", "⛈️", "storm"], 96: ["Thunderstorm with hail", "⛈️", "storm"], 99: ["Severe thunderstorm", "⛈️", "storm"]
};
const $ = (id) => document.getElementById(id);
const state = { data: null, unit: "c" };

const validate = (value) => {
  const city = value.trim();
  if (!city) return "Please enter a city name.";
  if (city.length < 2) return "City name is too short.";
  if (!/^[\p{L}\s.'-]+$/u.test(city)) return "Use letters only (no numbers or symbols).";
  return "";
};

async function getJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`The weather service returned an error (${res.status}). Try again later.`);
  return res.json();
}

async function fetchWeather(city) {
  const geo = await getJSON(`${GEO_URL}?name=${encodeURIComponent(city)}&count=1&language=en&format=json`);
  if (!geo.results || !geo.results.length) throw new Error(`No city found for "${city}". Check the spelling.`);
  const { latitude, longitude, name, admin1, country } = geo.results[0];
  const params = new URLSearchParams({
    latitude, longitude, timezone: "auto",
    current: "temperature_2m,relative_humidity_2m,apparent_temperature,wind_speed_10m,weather_code,is_day"
  });
  const w = await getJSON(`${WEATHER_URL}?${params}`);
  return { place: [name, admin1, country].filter(Boolean).join(", "), current: w.current };
}

const temp = (c) => state.unit === "c" ? `${Math.round(c)}°C` : `${Math.round(c * 9 / 5 + 32)}°F`;
const speed = (k) => state.unit === "c" ? `${Math.round(k)} km/h` : `${Math.round(k * 0.621371)} mph`;

function render() {
  const { place, current: c } = state.data;
  const [desc, icon, theme] = CODES[c.weather_code] || ["Unknown", "🌡️", "clear"];
  $("place").textContent = place;
  $("desc").textContent = desc;
  $("icon").textContent = c.is_day === 0 && theme === "clear" ? "🌙" : icon;
  $("temp").textContent = temp(c.temperature_2m);
  $("feels").textContent = temp(c.apparent_temperature);
  $("humidity").textContent = `${c.relative_humidity_2m}%`;
  $("wind").textContent = speed(c.wind_speed_10m);
  $("time").textContent = c.time.split("T")[1];
  document.body.className = c.is_day === 0 ? "night" : theme;
  $("result").hidden = false;
}

function showError(msg) {
  $("error").textContent = msg;
  $("city").setAttribute("aria-invalid", msg ? "true" : "false");
}

async function search(city) {
  const problem = validate(city);
  showError(problem);
  if (problem) return;
  $("loading").hidden = false;
  $("result").hidden = true;
  try {
    state.data = await fetchWeather(city.trim());
    render();
    saveRecent(state.data.place.split(",")[0]);
  } catch (err) {
    // fetch() throws TypeError when the network is down
    showError(err instanceof TypeError ? "Network problem. Check your internet connection and try again." : err.message);
  } finally {
    $("loading").hidden = true;
  }
}

function saveRecent(name) {
  try {
    const list = [name, ...JSON.parse(localStorage.getItem("recent") || "[]").filter((n) => n !== name)].slice(0, 5);
    localStorage.setItem("recent", JSON.stringify(list));
    drawRecent();
  } catch (e) { /* storage unavailable: ignore */ }
}

function drawRecent() {
  let list = [];
  try { list = JSON.parse(localStorage.getItem("recent") || "[]"); } catch (e) {}
  $("recent").replaceChildren(...list.map((n) => {
    const b = document.createElement("button");
    b.type = "button"; b.textContent = n;
    b.addEventListener("click", () => { $("city").value = n; search(n); });
    return b;
  }));
}

$("searchForm").addEventListener("submit", (e) => { e.preventDefault(); search($("city").value); });
document.querySelectorAll(".units button").forEach((b) => b.addEventListener("click", () => {
  state.unit = b.dataset.u;
  document.querySelectorAll(".units button").forEach((x) => x.setAttribute("aria-pressed", x === b));
  if (state.data) render();
}));
drawRecent();
